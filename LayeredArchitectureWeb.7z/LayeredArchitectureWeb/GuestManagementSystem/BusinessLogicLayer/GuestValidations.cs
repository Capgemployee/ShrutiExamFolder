﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Text.RegularExpressions;
using Entity;
using CustomException;
using DataAccessLayer;

namespace BusinessLogicLayer
{
    /// <summary>
    /// Class to validate Guest Record
    /// Author: 
    /// Date Modified: 8th march 2017
    /// Version No:
    /// Change Description: 
    /// </summary>
    public class GuestValidations
    {
        GuestOperations operationObj = new GuestOperations();

        /// <summary>
        /// Method to validate Guest record
        /// Author:
        /// Date Modified: 8th march 2017
        /// Version No:
        /// Change Description: 
        /// </summary>
        /// <param name="guestObj"></param>
        /// <returns></returns>
        //public bool ValidateGuest(Guest guestObj)
        //{
        //    bool validGuest = true;
        //    StringBuilder sb = new StringBuilder();
        //    if (guestObj.GuestID.ToString().Length == 0)
        //    {
        //        validGuest = false;
        //        sb.Append(Environment.NewLine + "Guest ID is required.");
        //    }
        //    if (guestObj.GuestName.Length == 0)
        //    {
        //        validGuest = false;
        //        sb.Append(Environment.NewLine + "Guest Name is required.");
        //    }
        //    if (guestObj.ContactNo.ToString().Length == 0)
        //    {
        //        validGuest = false;
        //        sb.Append(Environment.NewLine + "Guest Contact No is required.");
        //    }
        //    if (!(Regex.IsMatch(guestObj.GuestID.ToString(), @"^[0-9]+$")))
        //    {
        //        validGuest = false;
        //        sb.Append(Environment.NewLine + "Guest ID should contain only numbers.");
        //    }
        //    if (!(Regex.IsMatch(guestObj.GuestName, @"^[a-zA-Z ]+$")))
        //    {
        //        validGuest = false;
        //        sb.Append(Environment.NewLine + "Employee Name should contain only characters.");
        //    }
        //    if (!(Regex.IsMatch(guestObj.ContactNo.ToString(), @"^[0-9]+$")))
        //    {
        //        validGuest = false;
        //        sb.Append(Environment.NewLine + "Contact number should contain only numbers.");
        //    }
        //    if (guestObj.ContactNo.ToString().Length != 10)
        //    {
        //        validGuest = false;
        //        sb.Append(Environment.NewLine + "Conatct No should consist of 10 digits only.");
        //    }
        //    if (validGuest == false)
        //        throw new GuestException(sb.ToString());
        //    return validGuest;
        //}
        /// <summary>
        /// Method that calls a method that adds a Guest Record
        /// Author:
        /// Date Modified: 8th march 2017
        /// Version No:
        /// Change Description:
        /// </summary>
        /// <param name="guestObj"></param>
        /// <returns>bool</returns>
        public bool AddGuestRecord(Guest guestObj)
        {
            bool guestAdded=false;
           // if (ValidateGuest(guestObj))
                guestAdded = operationObj.AddGuestRecord(guestObj);
            return guestAdded;
        }

        /// <summary>
        /// Method that calls a method that returns the Guest information
        /// Author: 
        /// Date Modified: 8th march 2017
        /// Version No:
        /// Change Description: 
        /// </summary>
        /// <param name="guestID"></param>
        /// <returns>DataTable</returns>
        public DataTable GetGuestRecord(int guestID)
        {
         
            DataTable guestTable = operationObj.GetGuestRecord(guestID);
            return guestTable;
        }

        public DataTable GetGuestAllRecord()
        {

            DataTable guestTable = operationObj.GetGuestAllRecord();
            return guestTable;
        }

        public DataTable DeleteGuestRecord(int guestID)
        {
          
                    DataTable guestTable = operationObj.DeleteGuestRecord(guestID);
                    return guestTable;
    

        }

        public bool UpdateGuestRecord(Guest guestObj)
        {
            bool guestUpdated = false;
                guestUpdated = operationObj.UpdateGuestRecord(guestObj);
            return guestUpdated;
        }
    }
}
