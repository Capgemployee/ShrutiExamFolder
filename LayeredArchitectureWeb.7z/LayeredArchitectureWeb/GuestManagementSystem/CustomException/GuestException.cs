﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomException
{
    /// <summary>
    /// Class to throw custom exception
    /// Author: 
    /// Date Modified: 8th march 2017
    /// Version No:
    /// Change Description:
    /// </summary>
    public class GuestException:ApplicationException
    {
        public GuestException() : base() { }
        public GuestException(string message) : base(message) { }
    }
}
