Create table EmployeeDN
(
empid int primary key,
name varchar(10),
salary decimal(10,2),
city varchar(10)
)

drop table EmployeeDN

insert into EmployeeDN
values(101,'Shruti',2000,'Mumabi')
insert into EmployeeDN
values(102,'Mani',5000,'Nagpur')
insert into EmployeeDN
values(103,'Ayushi',20700,'Pune')
insert into EmployeeDN
values(104,'Shru',90000,'Mumabi')


CREATE PROC usp_InsertEmployeeDN
(
	@empid		INT,
	@name	VARCHAR(10),
	@salary		DECIMAL(10,2),
	@city		VARCHAR(10)
)
AS
BEGIN
	INSERT INTO EmployeeDN(empid, name, salary, city)
	VALUES (@empid, @name, @salary, @city)
END
GO

CREATE PROC usp_UpdateEmployeeDN
(
	@empid		INT,
	@name	VARCHAR(10),
	@salary		DECIMAL(10,2),
	@city		VARCHAR(10)
)
AS
BEGIN
	UPDATE EmployeeDN
	SET	name = @name,
		salary = @salary,
		city = @city
	WHERE empid = @empid
END


GO
CREATE PROC usp_DeleteEmployeeDN
(
	@empid	INT
)
AS
BEGIN
	DELETE FROM EmployeeDN WHERE empid = @empid
END

GO
CREATE PROC usp_DisplayEmployeeDN
AS
BEGIN
	SELECT * FROM EmployeeDN
END
GO

CREATE PROC usp_SearchEmployeeDN
(
	@empid	INT
)
AS
BEGIN
	SELECT * FROM EmployeeDN WHERE empid = @empid
END
GO

CREATE TABLE LoginUser_121824
(
	UserName	VARCHAR(10),
	Password	VARCHAR(10)
)
INSERT INTO LoginUser_115022 (UserName, Password)
VALUES ('admin', 'admin')
GO

CREATE PROC usp_ValidateLogin_121824
(
	@User	VARCHAR(10),
	@Password VARCHAR(10)
)
AS
BEGIN
	SELECT UserName FROM LoginUser_121824 
	WHERE UserName = @User AND Password = @Password
END
